

function Cart(){

    return (
    <div><h1>Cat 공간입니다.</h1></div>
    );
}

export default Cart;